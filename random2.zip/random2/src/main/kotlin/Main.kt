import kotlin.random.Random

fun main() {
    val numberOfShots = 3
    val numberOfTargets = 3
    val maxScorePerShot = 1

    var totalScore = 0

    for (shotNumber in 1..numberOfShots) {
        var shotScore = 0

        for (targetNumber in 1..numberOfTargets) {
            val hit = Random.nextBoolean()
            if (hit) {
                shotScore += maxScorePerShot
            }

            println("Выстрел $shotNumber в мишень $targetNumber: ${if (hit) "Попадание" else "Промах"}")
        }

        totalScore += shotScore
        println("Баллы за выстрел $shotNumber: $shotScore\n")
    }

    println("Общее количество баллов спортсмена: $totalScore")
}