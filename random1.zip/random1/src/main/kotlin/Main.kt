
import kotlin.random.Random

fun main() {
    val numberOfExams = 3
    val maxGrade = 10

    // Генерация оценок для каждого экзамена
    val examGrades = mutableListOf<Int>()

    for (i in 1..numberOfExams) {
        val isPreparedWell = Random.nextBoolean()
        val grade = if (isPreparedWell) {
            // Если ученик готовился хорошо, оценка от 8 до 10
            Random.nextInt(8, maxGrade + 1)
        } else {
            // Если ученик готовился плохо, оценка от 2 до 7
            Random.nextInt(2, 8)
        }
        examGrades.add(grade)
    }

    // Вывод оценок
    for (i in 0 until numberOfExams) {
        println("Оценка за экзамен ${i + 1}: ${examGrades[i]}")
    }
}
