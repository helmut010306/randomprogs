fun main() {
    val initialPopulation = 10_000_000 // Исходное население
    val yearsToSimulate = 10 // Количество лет для моделирования

    var population = initialPopulation
    var birthRate = 14.0 / 1000 // Рождаемость
    var deathRate = 8.0 / 1000 // Смертность

    for (year in 1..yearsToSimulate) {
        // Уменьшаем рождаемость и смертность на 1 человека
        birthRate -= 1.0 / 1000
        deathRate -= 1.0 / 1000

        // Учитываем ограничения на рождаемость и смертность
        if (birthRate < 7.0 / 1000) {
            birthRate = 7.0 / 1000
        }
        if (deathRate < 6.0 / 1000) {
            deathRate = 6.0 / 1000
        }

        // Рассчитываем прирост населения
        val births = (population * birthRate).toInt()
        val deaths = (population * deathRate).toInt()
        val populationChange = births - deaths

        // Обновляем численность населения
        population += populationChange
    }

    println("Численность населения через $yearsToSimulate лет: $population человек")
}